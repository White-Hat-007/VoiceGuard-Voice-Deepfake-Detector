# VoiceGuard

VoiceGuard is a locally run audio deepfake screening project. It fine-tunes a
Wav2Vec2 detector on labeled audio, evaluates it on separate validation and
held-out test sets, and reports overlapping time regions that receive high
fake scores.

The latest RTX 5060 fine-tuning run is in
`runs/wav2vec2_25k_fresh_test/`. It used 50,000 training clips (25,000 per
class), 4,000 validation clips, and 2,000 held-out test clips. On this
balanced ASVspoof 2021 DF test subset it measured **87.45% accuracy**,
**96.21% ROC-AUC**, **96.64% precision**, and **77.60% fake recall**, with a
decision threshold selected on validation data. Its test audio hashes do not
overlap the earlier test subset, but the clips still come from the same
official test partition and class-ordered source shards; this is not an
independent external benchmark. Results are benchmark-specific, not a
guarantee on other voices, codecs, or synthesis methods, and are not forensic
proof of authenticity.

## 1. Install on the RTX 5060 Laptop GPU

The project has been checked in this workspace with Python 3.10, PyTorch
2.11.0+cu128, and an RTX 5060 Laptop GPU (CUDA 12.8, compute capability 12.0).
For Blackwell, install a CUDA 12.8 PyTorch build:

```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install torch --index-url https://download.pytorch.org/whl/cu128
python -m pip install -r requirements.txt
python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CUDA unavailable')"
```

If PowerShell blocks activation, use `.\.venv\Scripts\python.exe` instead of
`python`. Training with `--require-cuda` exits rather than silently falling
back to CPU.

## 2. Download a real benchmark or prepare labeled audio

To automatically download a reproducible subset of the ASVspoof 2021
Deepfake (DF) benchmark, pin its source revision, sample it into the expected
folders, and record the selected source shards and audio hashes:

```powershell
python download_dataset.py --data-dir data --train-per-class 5000 --val-per-class 1000 --test-per-class 1000
```

The acquisition script keeps the benchmark's official train, validation, and
test partitions separate and samples without replacement from each. The
selected Hugging Face mirror is
[MoaazTalab/ASVspoof_2021_DF_Balanced_Normalized](https://huggingface.co/datasets/MoaazTalab/ASVspoof_2021_DF_Balanced_Normalized),
pinned to revision `479fbf291c9da1fca8c6b20d68b84442b2699f6b`. The original
[ASVspoof 2021 challenge page](https://www.asvspoof.org/index2021.html) says
its speech databases are available under the Open Data Commons Attribution
License (ODC-By). The mirror card does not independently state a license;
retain source attribution and verify terms before redistributing data or
trained artifacts. Downloaded audio and shard files are kept locally under
`data/` and are excluded from version control.

The generated `data/acquisition_manifest.json` records the dataset revision,
source split shards, deterministic sampling details, selected audio hashes,
and provenance. Training copies that evidence into the selected run's
`run_manifest.json`.

The mirror's parquet shards are class-ordered: some contain only fake clips
and others only real clips. Selecting a fresh test set by choosing different
shard numbers can therefore omit a class. To create a larger training sample
and a non-overlapping test sample from the official splits, exclude the hashes
in the prior acquisition manifest:

```powershell
python download_dataset.py --data-dir data\wav2vec2_generalization --source-dir data\_source --train-per-class 25000 --val-per-class 2000 --test-per-class 1000 --exclude-test-manifest data\acquisition_manifest.json --seed 42
```

The earlier 81.15% run's test subset had already been evaluated in multiple
model experiments, so treat that score as exploratory. The exclusion option
records the prior manifest and keeps its selected test audio out of the new
test sample; it does not create a new official benchmark partition.

Alternatively, arrange audio you are permitted to use in the folder layout
below:

For your own data, arrange **speaker/source-disjoint** partitions so the same
recording, speaker, or closely related source does not leak between splits:

```text
data/
  train/
    real/  *.wav, *.flac, or *.ogg
    fake/  *.wav, *.flac, or *.ogg
  val/
    real/
    fake/
  test/
    real/
    fake/
```

Use genuine and generated/deepfake recordings representative of the intended
use. Each of `train`, `val`, and `test` must contain at least one audio file in
both `real` and `fake`. Keep the test split untouched until final evaluation.
The loader supports WAV, FLAC, and OGG, resamples to 16 kHz, and converts
multi-channel audio to mono. If the standard decoder encounters a damaged
FLAC stream, FFmpeg is used as a fallback and its use is recorded in the
training manifest. No dataset is uploaded by this app.

## 3. Train and preserve evidence

```powershell
python train_transfer.py --data-dir data --output-dir runs/wav2vec2_asvspoof2019_transfer --max-per-class 5000 --require-cuda
python fine_tune_transfer.py --data-dir data\wav2vec2_generalization --source-run runs/wav2vec2_asvspoof2019_transfer --output-dir runs/wav2vec2_25k_fresh_test --max-per-class 25000 --epochs 10 --batch-size 8 --eval-batch-size 16 --encoder-learning-rate 1e-5 --head-learning-rate 1e-4 --unfrozen-layers 4 --patience 3 --seed 42 --require-cuda
```

The first stage uses a pinned Wav2Vec2 checkpoint trained on ASVspoof 2019 LA
and fits a new classification head on ASVspoof 2021 training data. The second
stage fine-tunes the top four encoder layers and head. It selects its best
checkpoint using validation ROC-AUC and chooses the decision threshold using
validation data; the held-out test split is not used for either choice.

The completed run contains:

| File | Evidence |
|---|---|
| `checkpoint.pt` | Fine-tuned model and validation-selected threshold |
| `training_history.csv` | Per-epoch loss and validation metrics |
| `evaluation.json` | Held-out test metrics, confusion matrix, and file-level scores |
| `run_manifest.json` | GPU, configuration, selected epoch, source checkpoint, and split-file hashes |

After training, create actual held-out real/fake detection examples and
presentation-ready PNG images directly from the saved model and run outputs:

```powershell
python generate_evidence.py --run-dir runs/wav2vec2_25k_fresh_test --data-dir data\wav2vec2_generalization
```

This adds `proof_training.png`, `proof_evaluation.png`,
`proof_detection_fake.png`, and `proof_detection_real.png`, plus
`detection_fake.json`, `detection_real.json`, and an `evidence_manifest.json`
that identifies the evidence sources. It also copies the two reference test
clips to `example_audio/` and packages the model, logs, metrics, manifest,
detection JSON, PNGs, example audio, and this README into
`VoiceGuard_Evidence.zip` for sharing. When available, the generator also
includes `proof_ui_upload.png`, `proof_ui_fake.png`, and `proof_ui_real.png`
from the project-root `proofs/` folder; these are browser captures of the live
upload interface and its completed predictions, explanations, and time-region
scores. The training terminal image renders a
report from the saved training history and run manifest; detection and results
terminal images render captured output from executed project commands. Raw
logs are included for verification. These are rendered terminal-output
images, not desktop screenshots. All current PNG proofs are copied into the
project-root `proofs/` folder for easy access; older smoke-run proof images
are not retained there.

Accuracy is the measured test-set result, not a target or guarantee. Report all
metrics and the split/data provenance when presenting results; do not tune on
the test set.

Run the unit checks with:

```powershell
python -m pytest
```

## 4. Detect audio and save output evidence

Command line:

```powershell
python detect.py path\to\sample.wav --model runs\wav2vec2_25k_fresh_test\checkpoint.pt --output runs\wav2vec2_25k_fresh_test\detection.json
```

Interactive upload interface:

```powershell
python -m streamlit run app.py
```

The interface and CLI return a `Real` or `Fake` screening decision, the mean
fake score, threshold, per-window scores, flagged time regions, and a concise
explanation of the score and strongest flagged region. The JSON result is
downloadable from the interface or can be saved using the CLI. “Reasons” are
model evidence (scores and temporal consistency), not proof of a specific
generation method. A low file-level score can coexist with locally flagged
regions; review the timeline rather than treating the label as forensic proof.
